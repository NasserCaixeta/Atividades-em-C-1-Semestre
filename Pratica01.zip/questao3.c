#include <stdio.h>
int main() {
float pi =  3.1416f;
float raio = 4.2f;
float perimetro = (2 * pi *  raio);
  
  printf("%s", "O perímetro é:");
  printf("%f",perimetro);
  
  return 0;
}