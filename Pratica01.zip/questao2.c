#include <stdio.h>


int main() {
int base = 2;
int altura = 3;

float area =(base * altura / 2 );
printf("%s", "A área é:");
printf("%f",area);

  return 0;
}