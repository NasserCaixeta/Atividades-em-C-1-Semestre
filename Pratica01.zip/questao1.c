#include <stdio.h>


int main(){
float a1 = 2.0f;
float a2 = 2.5f; 
float media = (a1 * 0.4) + (a2 * 0.6);
printf("%f\n",media);



  return 0;
}