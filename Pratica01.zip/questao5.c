#include <math.h>
#include <stdio.h>
int main(){
 float bytes = 1024;
 float gigabytes = 1024 * 1024 * 1024;
char resposta[31] = "O numero de bytes são:";
printf("%s", resposta);
  printf("%f", gigabytes);
  return 0;
}